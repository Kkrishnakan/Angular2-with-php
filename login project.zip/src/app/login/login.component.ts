import {Component} from '@angular/core';
import { HeroService } from '../hero.service';
import {FormControl, FormGroupDirective, NgForm} from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { NG_VALIDATORS,Validator,AbstractControl,ValidatorFn } from '@angular/forms';
//import {LoginService } from './login.service';
import { HttpClient } from '@angular/common/http';
import { Http, Response, Headers, HttpModule, RequestOptions, URLSearchParams, ResponseContentType } from '@angular/http';

@Component({
  selector: 'login-page',
  templateUrl: 'login.component.html'
})

export class LoginComponent {
  public email:any
  showHide:boolean;
  password;
  emailvalidator:boolean;
  
  headers: Headers;
  options: RequestOptions;
  constructor(private http: Http,private heroservice: HeroService ,private formBuilder: FormBuilder) { 
    this.headers = new Headers({ 'Content-Type': 'application/json', 'Accept': 'q=0.8;application/json;q=0.9' });
    this.options = new RequestOptions({ headers: this.headers });
    this.showHide = false;
  }

  submitted = false;
  onSubmit() { this.submitted = true; }
  ngOnInit() {
  }
  changeShowStatus(){
    this.showHide = !this.showHide;
  }
  myGroup: FormGroup;
  emailFormControl:any;
  login(e){
   
    this.heroservice.data.email= this.email;
console.log(this.heroservice.data.email);
  this.myGroup = new FormGroup({
    emailFormControl: new FormControl(['', [Validators.required, Validators.email]])
});
    
}
  // onSubmit(event){
  //   const data:any={
  //     email:this.emailid,
  //   }
  //   this.httpService.lg(data).subscribe(response => { 
  //     if (response.state === 'success') {
  //       alert("successfully added in database");
  //           }
  //         if (response.state === 'failure') {
  
  //         }
  //         },
  //     err => {
  //       const message = 'Error to load data';
  //     })
  
  // }
 
}