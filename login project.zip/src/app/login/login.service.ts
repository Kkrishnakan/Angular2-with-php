import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Http, Response, Headers, HttpModule, RequestOptions, URLSearchParams, ResponseContentType } from '@angular/http';
import {  ReplaySubject } from 'rxjs';
import { HeroService } from '../hero.service';
import { Observable} from "rxjs"
import { map, filter, catchError, mergeMap } from 'rxjs/operators';

import { Subject } from 'rxjs';

import 'rxjs/add/observable/of';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
@Injectable()
export class LoginService{
    headers: Headers;
    options: RequestOptions;
    constructor(private http: Http ) { 
      this.headers = new Headers({ 'Content-Type': 'application/json', 'Accept': 'q=0.8;application/json;q=0.9' });
      this.options = new RequestOptions({ headers: this.headers });
    }

    
    lg(data): Observable<any> {
        return this.http.post('http://localhost/api/login.php', data)
        //.pipe(map((res: Response) => res.json()));
       .map((res: Response) => res.json())
   //.pipe(map(data => data.json()))
         .catch(error => Observable.throw('Error in x service'));
     }
 //public data:any={
  
  // emailid:'',
  // name:'',
  // eemailid:'',
  // empolyeeid:'',
  // empoyeetype:'',
  // empolyeesource:'',
  // firstname:'',
  // middlename:'',
  // lastname:'',
  // profiletype:'',
  // skills:'',
  // phonenumber:'',
  // altphonenumber:'',
  // skypeid:'',
  

 //}

}
