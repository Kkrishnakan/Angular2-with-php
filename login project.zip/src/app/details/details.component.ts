import {Component} from '@angular/core';
import {FormControl, FormGroupDirective, NgForm, Validators} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { HeroService } from '../hero.service';
import { HttpClient } from '@angular/common/http';
import { Http, Response, Headers, HttpModule, RequestOptions, URLSearchParams, ResponseContentType } from '@angular/http';
export interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'details-page',
  templateUrl: 'details.component.html',
  styleUrls: ['details.component.css'],

})

export class DetailsComponent{


  headers: Headers;
  options: RequestOptions;
  constructor(private http: Http,  private heroservice: HeroService) { 
    this.headers = new Headers({ 'Content-Type': 'application/json', 'Accept': 'q=0.8;application/json;q=0.9' });
    this.options = new RequestOptions({ headers: this.headers });
}
  public empolyeeid:any;
  public empoyeetype:any;
  public empolyeesource:any;
  public firstname:any;
  public middlename:any;
  public lastname:any;
  public profiletype:any;
  public skills:any;
  public phonenumber:any;
  public altphonenumber:any;
  public skypeid:any;
  

  foods: Food[] = [
    {value: '0', viewValue: 'Option 1'},
    {value: '1', viewValue: 'Option 2'},
    {value: '2', viewValue: 'Option 3'},
    {value: '3', viewValue: 'Option 4'},
    {value: '4', viewValue: 'Option 5'},
    {value: '5', viewValue: 'Option 6'},
    {value: '6', viewValue: 'Option 7'},
    {value: '7', viewValue: 'Option 8'},
    {value: '8', viewValue: 'Option 9'},
    {value: '9', viewValue: 'Option 10'}
  ];
     

     // data = [];
  
    details(e){
   
      this.heroservice.data.empolyeeid= this.empolyeeid;
      this.heroservice.data.empoyeetype= this.empoyeetype;
      this.heroservice.data.empolyeesource= this.empolyeesource;
      this.heroservice.data.firstname= this.firstname;
      this.heroservice.data.middlename= this.middlename;
      this.heroservice.data.lastname= this.lastname;
      this.heroservice.data.profiletype= this.profiletype;
      this.heroservice.data.skills= this.skills;
      this.heroservice.data.phonenumber= this.phonenumber;
      this.heroservice.data.altphonenumber= this.altphonenumber;
      this.heroservice.data.skypeid= this.skypeid;
     
     this.heroservice.insrt(this.heroservice.data).subscribe(response => {
      if (response.state === 'success') {
  alert("successfully added in database");
      }
      if (response.state === 'failure') {
  
      }
    },
      err => {
        const message = 'Error to load data';
      })
  
    // console.log(this.heroservice.data);
    }


       //this.http.post('http://localhost/angula_test/signup.php', data).subscribe(response => {
        // this.httpService.details(data).subscribe(response => { 
        //   if (response.state === 'success') {
        //     alert("successfully added in database");
        //         }
        //       if (response.state === 'failure') {
      
        //       }
        //       },
        //   err => {
        //     const message = 'Error to load data';
        //   })
      
    
   
}