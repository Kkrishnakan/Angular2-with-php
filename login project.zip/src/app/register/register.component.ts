import {Component} from '@angular/core';
import {FormControl, FormGroupDirective, NgForm, Validators} from '@angular/forms';
import { NG_VALIDATORS,Validator,AbstractControl,ValidatorFn } from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { HeroService } from '../hero.service';
import { RegService   } from './reg.service';
import { HttpClient } from '@angular/common/http';
import { Http, Response, Headers, HttpModule, RequestOptions, URLSearchParams, ResponseContentType } from '@angular/http';


export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}
@Component({
  selector: 'register-page',
  templateUrl: 'register.component.html'
})

export class RegisterComponent {
   public name:string;
   public emailid:any;
    showHide:boolean;
    showHideBox:boolean;
    password;
    psd;
  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);
   headers: Headers;
  options: RequestOptions;
  constructor(private http: Http,private heroservice:HeroService) { 
    this.headers = new Headers({ 'Content-Type': 'application/json', 'Accept': 'q=0.8;application/json;q=0.9' });
    this.options = new RequestOptions({ headers: this.headers });

    this.showHide = false;
    this.showHideBox = false;
  }
  changeShowStatus(){
    this.showHide = !this.showHide;
  }
  changeShowStatus1(){
    this.showHideBox = !this.showHideBox;
    
  }
  sendCharacter (char: string) {
    var pass = [];
    pass.push(char);
    this.password = pass.join('');    
  }
  sendCharacters (char: string) {
    var pass = [];
    pass.push(char);
    this.psd = pass.join('');    
  }
  matcher = new MyErrorStateMatcher();
  reg(e){
   
    this.heroservice.data.name= this.name;
    this.heroservice.data.emailid= this.emailid;
   
    }

  // reg(){
  //   const data:any={
  //     name:this.name,
  //     email:this.emailid,
  //   }
  //   //this.http.post('http://localhost/angula_test/signup.php', data).subscribe(response => {
  //     this.httpService.create(data).subscribe(response => { 
  //       if (response.state === 'success') {
  //         alert("successfully added in database");
  //             }
  //           if (response.state === 'failure') {
    
  //           }
  //           },
  //       err => {
  //         const message = 'Error to load data';
  //       })
  // }
}